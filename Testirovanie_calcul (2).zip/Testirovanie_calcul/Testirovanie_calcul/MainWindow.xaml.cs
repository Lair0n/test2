﻿using NCalc;
using System;
using System.Windows;

namespace Testirovanie_calcul
{

    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public string fullExpression = "";
        public double memory;
        public MainWindow()
        {
            InitializeComponent();
        }

        public void btnSkobka1_Click(object sender, RoutedEventArgs e)
        {
            txbExpression.Text += btnSkobka1.Content.ToString();
        }

        public void btnSkobka2_Click(object sender, RoutedEventArgs e)
        {
            txbExpression.Text += btnSkobka2.Content.ToString();
        }

        public void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            txbExpression.Text = txbExpression.Text.Substring(0, txbExpression.Text.Length - 1);
        }

        public void btnReset_Click(object sender, RoutedEventArgs e)
        {
            txbExpression.Text = string.Empty;
            txbResult.Text = string.Empty;
        }

        public void btn1_Click(object sender, RoutedEventArgs e)
        {
            txbExpression.Text += btn1.Content.ToString();
        }

        public void btn2_Click(object sender, RoutedEventArgs e)
        {
            txbExpression.Text += btn2.Content.ToString();
        }

        public void btn3_Click(object sender, RoutedEventArgs e)
        {
            txbExpression.Text += btn3.Content.ToString();
        }

        public void btn4_Click(object sender, RoutedEventArgs e)
        {
            txbExpression.Text += btn4.Content.ToString();
        }

        public void btn5_Click(object sender, RoutedEventArgs e)
        {
            txbExpression.Text += btn5.Content.ToString();
        }

        public void btn6_Click(object sender, RoutedEventArgs e)
        {
            txbExpression.Text += btn6.Content.ToString();
        }

        public void btn7_Click(object sender, RoutedEventArgs e)
        {
            txbExpression.Text += btn7.Content.ToString();
        }

        public void btn8_Click(object sender, RoutedEventArgs e)
        {
            txbExpression.Text += btn8.Content.ToString();
        }

        public void btn9_Click(object sender, RoutedEventArgs e)
        {
            txbExpression.Text += btn9.Content.ToString();
        }

        public void btn0_Click(object sender, RoutedEventArgs e)
        {
            txbExpression.Text += btn0.Content.ToString();
        }

        public void btnDiv_Click(object sender, RoutedEventArgs e)
        {
            txbExpression.Text += btnDiv.Content.ToString();
        }

        public void btnMult_Click(object sender, RoutedEventArgs e)
        {
            txbExpression.Text += btnMult.Content.ToString();
        }

        public void btnSubtraction_Click(object sender, RoutedEventArgs e)
        {
            txbExpression.Text += btnSubtraction.Content.ToString();
        }

        public void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            txbExpression.Text += btnAdd.Content.ToString();
        }

        public void btnEqual_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                NCalc.Expression expr = new NCalc.Expression(fullExpression + txbExpression.Text);
                object result = expr.Evaluate();

                if (result != null)
                {
                    txbResult.Text = result.ToString();
                    memory = Convert.ToDouble(txbResult.Text);
                }
                else
                {
                    txbResult.Text = "Error";
                }
            }
            catch (Exception ex)
            {
                txbResult.Text = "Error: " + ex.Message;
            }
        }

        public void btnMod_Click(object sender, RoutedEventArgs e)//остаток от деления
        {
            try
            {
                string number = txbExpression.Text;
                fullExpression = number + " % ";
                txbExpression.Text = "";
            }
            catch (Exception ex)
            {
                txbResult.Text = "Error: " + ex.Message;
            }
        }

        public void btnMR_Click(object sender, RoutedEventArgs e)
        {
            MemoryRecall();
        }
        // Метод для кнопки MR (Memory Recall)
        public void MemoryRecall()
        {
            txbResult.Text = memory.ToString();
        }

        // Метод для кнопки MC (Memory Clear)
        public void MemoryClear()
        {
            memory = 0;
        }

        // Метод для кнопки M+ (Memory Add)
        public void MemoryAdd()
        {
            if (!string.IsNullOrEmpty(txbResult.Text))
            {
                if (double.TryParse(txbResult.Text, out double number))
                {
                    memory += number;
                }
            }
        }

        public void btnMplus_Click(object sender, RoutedEventArgs e)
        {
            MemoryAdd();
        }

        public void btnMC_Click(object sender, RoutedEventArgs e)
        {
            MemoryClear();
        }
    }
}
