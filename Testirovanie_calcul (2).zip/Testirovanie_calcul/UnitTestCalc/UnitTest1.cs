﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Testirovanie_calcul;

namespace UnitTestCalc
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            string res = "10";

            MainWindow mainWindow = new MainWindow();

            mainWindow.btn6_Click(null, null); 
            mainWindow.btnAdd_Click(null, null);
            mainWindow.btn4_Click(null, null); 

            mainWindow.btnEqual_Click(null, null);
            
            Assert.AreEqual(res, mainWindow.txbResult.Text);
        }

        [TestMethod]
        public void TestMethod2()
        {
            string res = "60";

            MainWindow mainWindow = new MainWindow();

            mainWindow.btn6_Click(null, null);
            mainWindow.btnMult_Click(null, null);
            mainWindow.btn1_Click(null, null);
            mainWindow.btn0_Click(null, null);      
            mainWindow.btnEqual_Click(null, null);

            Assert.AreEqual(res, mainWindow.txbResult.Text);
        }
        [TestMethod]
        public void TestMethod3()
        {
            string res = "25";

            MainWindow mainWindow = new MainWindow();

            mainWindow.btn5_Click(null, null);
            mainWindow.btn0_Click(null, null);
            mainWindow.btnDiv_Click(null, null);
            mainWindow.btn2_Click(null, null);
            mainWindow.btnEqual_Click(null, null);

            Assert.AreEqual(res, mainWindow.txbResult.Text);
        }
        [TestMethod]
        public void TestMethod4()
        {
            string res = "0";

            MainWindow mainWindow = new MainWindow();

            mainWindow.btn5_Click(null, null);
            mainWindow.btn0_Click(null, null);
            mainWindow.btnDiv_Click(null, null);
            mainWindow.btn0_Click(null, null);
            mainWindow.btnEqual_Click(null, null);

            Assert.AreEqual(res, mainWindow.txbResult.Text);
        }
        [TestMethod]
        public void TestMethodVoid()
        {
            string res = "Вы должны заполнить поле";

            MainWindow mainWindow = new MainWindow();

            mainWindow.btnEqual_Click(null, null);

            Assert.AreEqual(res, mainWindow.txbResult.Text);
        }
    }
}
